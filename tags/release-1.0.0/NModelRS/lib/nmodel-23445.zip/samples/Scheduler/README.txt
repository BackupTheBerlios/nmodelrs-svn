Illustrates a model of a scheduler. 
Build the model with VS or run:
>build

To view the model program run:
>mpv @mpv_args.txt