Reactive system model from section 5.7, with public declarations and
progress messages, could be used to run simulations as in 5.5

Build from VS at at the commmand prompt 

> build

To display the unsafe states as in figure 6.9

> mpv @mpv_safety.txt

Notice that progress messages are written to the console as mpv
explores the model.
