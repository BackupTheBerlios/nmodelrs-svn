Composition examples from section 7.3.1

Nothing needs compiling here.

Figure 7.6:

> mpv /fsm:M1.txt

Figure 7.7:

> mpv /fsm:M2.txt

Figure 7.8:

> mpv /fsm:M1.txt /fsm:M2.txt

Figure 7.9:

> mpv /fsm:M1-loop.txt

Figure 7.10:

> mpv /fsm:M2-loop.txt

Figure 7.12

> mpv /fsm:M1.txt /fsm:M2.txt

then (from drop-down menu in upper left corner) select M2.txt to see
the projection of M1 x M2 onto M2
