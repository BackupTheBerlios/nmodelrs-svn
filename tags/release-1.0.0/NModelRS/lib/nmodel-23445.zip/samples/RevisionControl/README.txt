To build the RevisionControl sample use VS or run
>build

To view a scenario with mpv run
>mpv @mpv_args.txt
