Includes several examples of mpv and ct. 
Uses the sample protocol model SP from Chapter 14.
Covers several examples used in Chapter 14.

In order to view any of the examples first run 

> build.bat

or build the files using Visual Studio.

Then, in order to see an mpv example, run 

> mpv @mpv_<example>.txt

and in order to see a ct example, run 

> ct @ct_args.txt


