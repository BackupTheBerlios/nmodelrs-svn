Illustrates the use of MDP based strategies. 
To build the example dlls use Visual Studio or:

>build


To run the mpv tool:

>mpv @mpv_args.txt


To run the ct tool:

>ct @ct_args.txt
