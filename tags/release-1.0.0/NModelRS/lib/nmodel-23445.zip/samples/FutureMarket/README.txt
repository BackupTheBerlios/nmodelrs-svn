Build the sample from VS or run:
>build

This example has no implementation. 
To view th model program with mpv run:

> mpv @fm.txt