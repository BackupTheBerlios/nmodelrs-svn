using System.Reflection;

[assembly: AssemblyCompany("Microsoft")]
[assembly: AssemblyProduct("NModel")]
[assembly: AssemblyCopyright("Copyright © Microsoft 2007")]
[assembly: AssemblyVersion("1.0.21029.0")]
[assembly: AssemblyFileVersion("1.0.21029.0")]
