using System;
using System.Collections.Generic;
using System.Text;
using NModel.Utilities.Graph;

namespace Mp2Dot
{
    class Program
    {
        static void Main(string[] args)
        {
            CommandLineViewer.RunWithCommandLineArguments(args);
        }
    }
}
