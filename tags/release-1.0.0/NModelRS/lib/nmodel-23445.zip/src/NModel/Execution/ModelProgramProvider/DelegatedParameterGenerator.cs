using System;
using System.Collections.Generic;
using System.Text;
using NModel.Terms;

namespace NModel.Execution
{
    //public delegate IEnumerable<Sequence<Term>> ArgumentGenerator(Symbol symbol, IState state);

    //internal class DelegatedParameterGenerator : IParameterGenerator
    //{
    //    Symbol sym;
    //    ArgumentGenerator gen;

    //    public DelegatedParameterGenerator(ArgumentGenerator gen, Symbol sym)
    //    {
    //        this.gen = gen;
    //        this.sym = sym;
    //    }


    //    #region IParameterGenerator Members

    //    public IEnumerable<Sequence<Term>> GetParameters(IState state)
    //    {
    //        return this.gen(this.sym, state);
    //    }

    //    #endregion
    //}
}
        