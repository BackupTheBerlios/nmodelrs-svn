//-------------------------------------
// Copyright (c) Microsoft Corporation
//-------------------------------------
using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using NModel.Internals;
using NModel.Terms;
using NModel.Attributes;


namespace NModel.Execution.ModelProgramProvider
{
    //internal class StateProperty
    //{
    //    PropertyInfo info;

    //    StateProperty(PropertyInfo info)
    //    {
    //        this.info = info;
    //    }

    //    internal PropertyInfo Info
    //    {
    //        get { return info; }
    //    }

    //}
}
