using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Win32;
using NModel.Algorithms;

namespace NModel.Utilities
{
    //internal static class InstallHelper
    //{
    //    public static string GetInstallationDirectory()
    //    {
    //        using (RegistryKey rg = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Modeling\CurrentVersion\InstallPath"))
    //        {
    //            if (rg != null)
    //                return (string)rg.GetValue(null);
    //        }

    //        return System.IO.Path.Combine(System.IO.Path.GetDirectoryName(typeof(InstallHelper).Assembly.Location));
    //    }
    //}
}
