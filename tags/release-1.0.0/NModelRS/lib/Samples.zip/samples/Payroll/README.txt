Build the Pyroll sample by using VS or run
>build

To view a scenario of the Paroll model program with mpv run
>mpv @mpv_args.txt
