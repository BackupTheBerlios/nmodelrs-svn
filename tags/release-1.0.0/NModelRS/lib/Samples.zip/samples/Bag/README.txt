Illustrates different uses of mpv, ct and otg  with the bag example
that is introduced in Chapter 12.

In order to run the examples, first run 

>build

or build the samples from Visual studio


In order to run 

>ct @ct_args1.txt 

you must first run 

>otg @otg_args.txt

to produce a test suite that is saved in a file 'testSuite.txt'

